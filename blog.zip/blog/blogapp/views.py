from .models import *
from .forms import SearchForm,CommentForm
from django.shortcuts import render,redirect

def BlogListView(request):
    dataset = BlogModel.objects.all()
    if request.method == 'POST':
        form = SearchForm(request.POST)
        if form.is_valid():
            title = form.cleaned_data['title']
            blog = BlogModel.objects.get(blog_title=title)
            return redirect(f'/blog/{blog.id}')
    else:
        form = SearchForm()
        context = {
            'dataset':dataset,
            'form':form,
        }
    return render(request,'blogapp/listview.html',context)


def BlogDetailView(request,_id):
    
    try:
        data =BlogModel.objects.get(id =_id)
        comments = CommentModel.objects.filter(blog = data)
    except BlogModel.DoesNotExist:
        raise Http404('Data does not exist')
    
    if request.method == 'POST':
          
        form = CommentForm(request.POST)
        
        if form.is_valid():       
            if request.POST.get('sub')=='Comment':
                Comment = CommentModel(your_name= form.cleaned_data['your_name'],
                comment_text=form.cleaned_data['comment_text'],
                blog=data)
                Comment.save()
                return redirect(f'/blog/{_id}')
            if request.POST.get('sub')=='Delete':
               CommentModel.objects.filter(your_name=form.cleaned_data['your_name']).first().delete()
               return redirect(f'/blog/{_id}')
            if request.POST.get('sub')=='Edit':  
                Comment = CommentModel.objects.filter(your_name=form.cleaned_data['your_name']).first()
                Comment.comment_text=form.cleaned_data['comment_text']
                Comment.save()
                return redirect(f'/blog/{_id}') 

         
    else:
        form = CommentForm()

    context = {
            'data':data,
            'form':form,
            'comments':comments,
        }
    return render(request,'blogapp/detailview.html',context)

# def DeleteView(request,):
#     import pdb;pdb.set_trace()
#     form = CommentForm(request.POST)

#     if request.method == 'POST':
#         form = CommentForm(request.POST)
#         if form.is_valid():       
#            CommentModel.objects.filter(name)
#         # context = {
#         #     'data':"data",
#         #     'form':form,
#         #     'comments':"",
#         # }
#     return render(request,'blogapp/detailview.html')        
#    # return render(request,'blogapp/detailview.html',context)

